#include <LPC17xx.H>     /* Definiciones para el LPC17xx */

int32_t i;

//Funci�n que de retardo
void delay_1ms(uint32_t ms)
{
   	uint32_t n;
   	for(n=0;n<ms*14283;n++);
}

int main(void)
{
  while(1){
    if(i==0) {
      i=1;
      delay_1ms(25);     
    }
    else{
      i=0;
      delay_1ms(25);     
    }
   }
}

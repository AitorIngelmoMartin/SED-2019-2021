
/* delay.h */
#include "lpc17xx.h"

void delay_1ms(uint32_t ms);


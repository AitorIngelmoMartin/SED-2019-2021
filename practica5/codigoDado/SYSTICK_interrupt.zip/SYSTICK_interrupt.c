/*----------------------------------------------------------------------------
 * Name:    SYSTIC_interrupt.c
 *----------------------------------------------------------------------------*/

#include "LPC17xx.H"	   
uint32_t pulsador;
uint32_t SystemFrequency=100000000;

volatile uint32_t cuenta;  // Contador de veces de x ms 

void SysTick_Handler (void)			// Rutina (ISR) de atenci�n...
                                    //... a la excepci�n 15 -del SYSTICK-
{
  cuenta ++;	                    // Incrementar countadores cada 10ms  y cada 1s
	
	
}


int main (void)
  {
  LPC_GPIO3->FIODIR |= (1<<25);	  // P3.25 definido como salida
  LPC_GPIO3->FIODIR |= (1<<26);	  // P3.26 definido como salida  
  LPC_GPIO2->FIODIR &= ~(1<<12);  // P2.12 definido como entrada  
  
	
  // SystemInit ();                // Initializar relojes " clocks"
	
  SysTick_Config (SystemFrequency/100);    // Configurar  SYSTICK

  while (1)
		{
    pulsador=((LPC_GPIO2->FIOPIN & (1<<12))>>12);  
    if (pulsador==0){               // pulsador pulsado? 
   
      if (cuenta==3)LPC_GPIO3->FIOPIN &= ~(1<<25);  // enciendo LED
       if (cuenta>=3*2){
	      LPC_GPIO3->FIOPIN   |= (1<<25);           // apago LED
		 cuenta=0;
          }
       }
    else{
     
       if (cuenta==6) LPC_GPIO3->FIOPIN &= ~(1<<26); // enciendo LED
       if (cuenta>=6*2){
          LPC_GPIO3->FIOPIN |= (1<<26);              // apago LED 
    	  cuenta=0;
          }
    } 
  }
}

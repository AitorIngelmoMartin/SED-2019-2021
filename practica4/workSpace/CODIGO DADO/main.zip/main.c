//controlador de interrupciones


#include <LPC17xx.H>

char a=1, b=1, c=1;


//Funci�n que inicializa las interrupciones
void inicioPINSEL()
{

//Configuraci�n de los pines P2.10 a P2.12, como entradas de interrupci�n
 LPC_PINCON->PINSEL4 |= 1 << (10*2);   
 LPC_PINCON->PINSEL4 |= 1 << (11*2);   
 LPC_PINCON->PINSEL4 |= 1 << (12*2);   
//Configuraci�n de los pines P2.0 a P2.2, como GPIO
 LPC_PINCON->PINSEL4 &= ~ (3 << (0*2));  
 LPC_PINCON->PINSEL4 &= ~ (3 << (1*2));  
 LPC_PINCON->PINSEL4 &= ~ (3 << (2*2));  
}

void inicioIRQs()
{
//Asignaci�n de prioridades
  NVIC_SetPriorityGrouping(4);
  NVIC_SetPriority(EINT0_IRQn, 0x4);
  NVIC_SetPriority(EINT1_IRQn, 0x6);
  NVIC_SetPriority(EINT2_IRQn, 0x2);

//Habilitaci�n de las interrupciones
  NVIC_EnableIRQ(EINT0_IRQn);
  NVIC_EnableIRQ(EINT1_IRQn);
  NVIC_EnableIRQ(EINT2_IRQn);
}

//ISR de las interrupciones
void EINT0_IRQHandler()
{
  LPC_SC->EXTINT |= (1);   // Borrar el flag de la EINT0 --> EXTINT.0
  LPC_GPIO2->FIOSET=0x00000001;   // Activar el pin P2.0
  while(a) ;
  LPC_GPIO2->FIOCLR=0x00000001;   // Desactivar el pin P2.0
}

void EINT1_IRQHandler()
{
  LPC_SC->EXTINT |= (1 << 1);   // Borrar el flag de la EINT1 --> EXTINT.1
  LPC_GPIO2->FIOSET=0x00000002;   // Activar el pin P2.1
  while(b);
  LPC_GPIO2->FIOCLR=0x00000002;   // Desactivar el pin P2.1
}

void EINT2_IRQHandler()
{
LPC_SC->EXTINT |= (1 << 2);   // Borrar el flag de la EINT2 --> EXTINT.2
  LPC_GPIO2->FIOSET=0x00000004;   // Activar el pin P2.2
  while(c);
  LPC_GPIO2->FIOCLR=0x00000004;   // Activar el pin P2.2
}

//Programa principal
main ()
{
  inicioPINSEL();

  inicioIRQs();

  while(1);
}


